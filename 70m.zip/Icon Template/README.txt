Here is how to use the templates: 

https://www.notion.so/Using-the-Sketch-Figma-Templates-88083972eed4444d85d30c2d06f8ab4c